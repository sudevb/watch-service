package com.mufg.poc.batch.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BaseDto {
    // You can add common properties here
    private Long id;
}
