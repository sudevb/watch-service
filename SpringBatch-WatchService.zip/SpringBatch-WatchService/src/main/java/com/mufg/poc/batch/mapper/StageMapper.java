package com.mufg.poc.batch.mapper;

import com.mufg.poc.batch.domain.Product;
import com.mufg.poc.batch.domain.Stage;
import com.mufg.poc.batch.domain.Trade;
import com.mufg.poc.batch.dto.ProductDto;
import com.mufg.poc.batch.dto.StageDto;
import com.mufg.poc.batch.dto.TradeDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface StageMapper {
    Stage toStage(StageDto stageDto);
    Product toProduct(StageDto productDto);
    Trade toTrade(StageDto tradeDto);
}
