package com.mufg.poc.batch.config;

import com.mufg.poc.batch.domain.Stage;
import com.mufg.poc.batch.dto.StageDto;
import com.mufg.poc.batch.mapper.StageMapper;
import com.mufg.poc.batch.repositories.ProductRepository;
import com.mufg.poc.batch.repositories.StageRepository;
import com.mufg.poc.batch.repositories.TradeRepository;
import lombok.val;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.transaction.PlatformTransactionManager;

import java.io.IOException;

@Configuration
public class StageMapBatchConfig {

    @Bean
    public Job importStageMapJob(final JobRepository jobRepository, final PlatformTransactionManager transactionManager,
                                 final StageRepository stageRepository, final ProductRepository productRepository,
                                 final TradeRepository tradeRepository, final StageMapper stageMapper) throws IOException {
        return new JobBuilder("importStageMapJob", jobRepository)
                .incrementer(new RunIdIncrementer())
                .start(importStageMapStep(jobRepository, transactionManager, stageRepository, productRepository, tradeRepository, stageMapper))
                .build();
    }

    @Bean
    public Step importStageMapStep(final JobRepository jobRepository, final PlatformTransactionManager transactionManager,
                                   final StageRepository stageRepository, final ProductRepository productRepository,
                                   final TradeRepository tradeRepository, final StageMapper stageMapper) throws IOException {
        return new StepBuilder("importStageMapStep", jobRepository)
                .<StageDto, Object>chunk(100, transactionManager)
                .reader(flatFileItemReader(null))
                .processor(itemProcessor(stageMapper))
                .writer(stageItemWriter(stageRepository, productRepository, tradeRepository))
                .build();
    }

    @Bean
    public ItemProcessor<StageDto, Object> itemProcessor(final StageMapper stageMapper) {
        return new StageItemProcessor(stageMapper);
    }

    @Bean
    public StageItemWriter stageItemWriter(final StageRepository stageRepository, final ProductRepository productRepository, final TradeRepository tradeRepository) {
        return new StageItemWriter(stageRepository, productRepository, tradeRepository);
    }

    @Bean
    @StepScope
    public FlatFileItemReader<StageDto> flatFileItemReader(@Value("#{jobParameters['inputFile']}") final String visitorsFile) throws IOException {
        val flatFileItemReader = new FlatFileItemReader<StageDto>();
        flatFileItemReader.setName("STAGE_READER");
        flatFileItemReader.setLinesToSkip(1);
        flatFileItemReader.setLineMapper(lineMapper());
        flatFileItemReader.setStrict(false);
        flatFileItemReader.setResource(new FileSystemResource(visitorsFile));
        return flatFileItemReader;
    }

    @Bean
    public LineMapper<StageDto> lineMapper() {
        val defaultLineMapper = new DefaultLineMapper<StageDto>();
        val lineTokenizer = new DelimitedLineTokenizer();
        lineTokenizer.setDelimiter(",");
        lineTokenizer.setNames("stageId", "name", "type", "category", "fileType");
        lineTokenizer.setStrict(false);
        defaultLineMapper.setLineTokenizer(lineTokenizer);
        defaultLineMapper.setFieldSetMapper(new StageFieldSetMapper());
        return defaultLineMapper;
    }
}
