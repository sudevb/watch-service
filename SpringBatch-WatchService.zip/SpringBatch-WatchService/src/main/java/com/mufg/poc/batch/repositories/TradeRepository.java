// src/main/java/br/com/spring/batch/repository/StageTableRepository.java
package com.mufg.poc.batch.repositories;

import com.mufg.poc.batch.domain.Trade;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TradeRepository extends JpaRepository<Trade, Long> {
}
