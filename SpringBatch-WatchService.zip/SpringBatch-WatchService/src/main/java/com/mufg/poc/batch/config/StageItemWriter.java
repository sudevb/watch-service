package com.mufg.poc.batch.config;

import com.mufg.poc.batch.domain.Product;
import com.mufg.poc.batch.domain.Stage;
import com.mufg.poc.batch.domain.Trade;
import com.mufg.poc.batch.repositories.ProductRepository;
import com.mufg.poc.batch.repositories.StageRepository;
import com.mufg.poc.batch.repositories.TradeRepository;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

@Component
public class StageItemWriter implements ItemWriter<Object> {

    private final StageRepository stageRepository;
    private final ProductRepository productRepository;
    private final TradeRepository tradeRepository;

    public StageItemWriter(StageRepository stageRepository, ProductRepository productRepository, TradeRepository tradeRepository) {
        this.stageRepository = stageRepository;
        this.productRepository = productRepository;
        this.tradeRepository = tradeRepository;
    }

    @Override
    public void write(Chunk<? extends Object> items) {
        for (Object item : items) {
            if (item instanceof Product) {
                productRepository.save((Product) item);
            } else if (item instanceof Trade) {
                tradeRepository.save((Trade) item);
            } else if (item instanceof Stage) {
                stageRepository.save((Stage) item);
            }
        }
    }
}
