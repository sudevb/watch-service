// src/main/java/br/com/spring/batch/domain/StageTable.java
package com.mufg.poc.batch.dto;

import jakarta.persistence.Id;
import lombok.*;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductDto extends BaseDto {
    private Long stageId;
    private String name;
    private String type;
    private String category;
    private String fileType;
}
