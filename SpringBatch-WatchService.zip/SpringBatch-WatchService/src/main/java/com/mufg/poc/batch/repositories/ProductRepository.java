// src/main/java/br/com/spring/batch/repository/StageTableRepository.java
package com.mufg.poc.batch.repositories;

import com.mufg.poc.batch.domain.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {
}
