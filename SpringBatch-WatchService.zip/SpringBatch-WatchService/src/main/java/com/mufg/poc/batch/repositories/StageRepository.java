// src/main/java/br/com/spring/batch/repository/StageTableRepository.java
package com.mufg.poc.batch.repositories;

import com.mufg.poc.batch.domain.Stage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StageRepository extends JpaRepository<Stage, Long> {
}
