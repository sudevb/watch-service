package com.mufg.poc.batch.config;

import com.mufg.poc.batch.domain.Product;
import com.mufg.poc.batch.domain.Stage;
import com.mufg.poc.batch.domain.Trade;
import com.mufg.poc.batch.dto.StageDto;
import com.mufg.poc.batch.mapper.StageMapper;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

@Component
public class StageItemProcessor implements ItemProcessor<StageDto, Object> {
    private final StageMapper stageMapper;

    public StageItemProcessor(StageMapper stageMapper) {
        this.stageMapper = stageMapper;
    }

    @Override
    public Object process(final StageDto stageDto) {
        if (stageDto.getFileType().equalsIgnoreCase("product")) {
            Product product = stageMapper.toProduct(stageDto);
            return product;
        } else if (stageDto.getFileType().equalsIgnoreCase("trade")) {
            Trade trade = stageMapper.toTrade(stageDto);
            return trade;
        } else {
            Stage stage = stageMapper.toStage(stageDto);
            return stage;
        }
    }
}
