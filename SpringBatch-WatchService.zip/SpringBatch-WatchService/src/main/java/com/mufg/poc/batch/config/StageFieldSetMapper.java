package com.mufg.poc.batch.config;

import com.mufg.poc.batch.dto.StageDto;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

public class StageFieldSetMapper implements FieldSetMapper<StageDto> {
    @Override
    public StageDto mapFieldSet(final FieldSet fieldSet) throws BindException {
        return StageDto.builder()
                .stageId(fieldSet.readLong("stageId"))
                .name(fieldSet.readString("name"))
                .type(fieldSet.readString("type"))
                .category(fieldSet.readString("category"))
                .fileType(fieldSet.readString("fileType"))
                .build();
    }
}
